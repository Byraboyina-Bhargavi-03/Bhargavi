function convertToFar() {
    var celsius = document.getElementById("celsius").value;
    var result = (celsius * 9/5) + 32;
    document.getElementById("resultFar").innerHTML = "Result: " + result + "°F";
  }
  
  function convertToCel() {
    var fahrenheit = document.getElementById("fahrenheit").value;
    var result = (fahrenheit - 32) * 5/9;
    document.getElementById("resultCel").innerHTML = "Result: " + result + "°C";
  }
  